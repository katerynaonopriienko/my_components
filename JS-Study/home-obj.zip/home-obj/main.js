// задание query search
// location search 
function qs(pr) {
    var str = '?name=evgeniy&age=39';
    var a = str.replace('?', '');
    // console.log(a);
    var ar = a.split('&');
    // console.log(ar);
    var newObj = {};
    for (var i=0; i < ar.length; i++ ) {
    	var prop = ar[i].split('=')[0];
       	var value = ar[i].split('=')[1];
       	newObj[prop] = value;
        // console.log(prop +':'+ newObj[prop])
        for (var prop in newObj) {
            if (prop === pr) {
                return newObj[prop];
            }
        }
    }
}

// qs();
console.log(qs('name'));